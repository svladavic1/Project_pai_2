
figure(1)
plot(vrijeme_uzl,uzlazni_napon);
title('Zagrijavanje')
xlabel('Vrijeme(s)');
ylabel('Napon na otporu');
grid on;
figure(2)
plot(vrijeme_sil,silazni_napon);
title('Hla�enje')
grid on;
xlabel('Vrijeme(s)');
ylabel('Napon na otporu');
%Staticka karakteristika NTC termistora
%Otpor uzlazno
Temp = 25 : 1 :80;
R_uzl = [5.75 5.37 5.01 4.8 4.58 4.24 4.1 3.95 3.77 3.62 3.54 3.33 3.25 3.06 2.93 2.87 2.7 2.57 2.5 2.4 2.32 2.22 2.157 2.1 2 1.93 1.84 1.77 1.7 1.633 1.56 1.5 1.52 1.46 1.402 1.35 1.29 1.27 1.2 1.2 1.161 1.132 1.1 1.061 1.035 1.028 1.003 0.983 0.952 0.933 0.903 0.888 0.866 0.837 0.818 0.798];
figure(3)
title('Stati�ka karakteristika termistora')
plot(Temp, R_uzl);
hold on;
grid on;
plot(Temp,R_sil);
R_sil = [5.75 5.34 5.18 4.98 4.87 4.74 4.45 4.22 4.04 3.97 3.87 3.732 3.654 3.556 3.439 3.27 3.179 3.036 2.928 2.834 2.704 2.623 2.435 2.39 2.349 2.286 2.18 2.125 2.045 1.995 1.89 1.845 1.78 1.722 1.659 1.597 1.55 1.485 1.443 1.388 1.365 1.32 1.272 1.238 1.203 1.175 1.138 1.1 1.063 1.033 1 0.98 0.948 0.92 0.897 0.866];
legend('Stati�ka karakteristika dobivena uzlaznom putanjom (zagrijavanjem)','Stati�ka karakteristika dobivena silaznom putanjom (hla�enjem)')
xlabel('Temperatura [\circ C]');
ylabel('Otpor NTC termistora [k\Omega]');
axis([24 85 0 6]);
%Za potrebe usrednjivanja korsitit �u obje 
R_ukupno = [R_uzl, R_sil];
Temp_ukupno = [Temp,Temp];
Temp_ukupno= Temp_ukupno + 273;
Temp = Temp + 273;
%Vise manje za sve isprobane karakteristike ispostavi se da je greska
%negdje oko 2.5 (kada se gleda usrednjena vrijednost). 
%Napomene. Napon napajanja ventilatora je 4.6 V, napon napajanja spoja je 8
%V.f(x) = a*exp(b/x)
%Coefficients (with 95% confidence bounds):
%a =   1.964e-05  (1.376e-05, 2.552e-05)
%b =        3741  (3648, 3833)
%Uzet ce se ova gdje je temperatura data u kelvinima, pa ce se pretvoriti
%temperatura u celzijuse
figure(4)
a =   1.964e-05;
b =        3741;
R_aproksimacija = a.*exp(b./Temp);
title('Stati�ka karakteristika termistora')
plot(Temp, R_uzl,'*');
hold on;
grid on;
plot(Temp,R_sil,'x');
plot(Temp,R_aproksimacija);
legend('Stati�ka karakteristika dobivena uzlaznom putanjom (zagrijavanjem)','Stati�ka karakteristika dobivena silaznom putanjom (hla�enjem)','Aproksimirana stati�ka karakteristika')
xlabel('Temperatura [K]');
ylabel('Otpor NTC termistora [k\Omega]');
axis([295  356 0 6]);
%Sa ovom karakteristikom se sada moze napraviti zavisnost promjene napona
%od temperature u konkretnoj shemi
%Sad ce se navesti kako se napon mijenjao u zavinosti od temperature i onda
%uz pomoc aproksimirane stati�ke karakteristike NTC termistora
%Jer je aproksimacija najbolja za Kelvine drzat cu se kelvina odavde pa
%onda kada je dovedeno pred kraj pretvoriti u celzijuse
figure(5)
U_v_ulz = (8.*3.3)./(3.3 + R_uzl);
U_v_sil = (8.*3.3)./(3.3 + R_sil);
U_v_aproksimacija = (8.*3.3)./(3.3 + R_aproksimacija);
title('Promjena napona na otporniku u zavisnosti od temperature')
plot(Temp, U_v_ulz,'*');
hold on;
grid on;
plot(Temp,U_v_sil,'x');
plot(Temp,U_v_aproksimacija);
legend('Stati�ka karakteristika dobivena uzlaznom putanjom (zagrijavanjem)','Stati�ka karakteristika dobivena silaznom putanjom (hla�enjem)','Aproksimirana stati�ka karakteristika')
xlabel('Temperatura [K]');
ylabel('Napon [V]');
%Sada hocu da opisem zagrijavanje sistema, ovisnsot temperature od vremena
NTC_uzl = (8*3.3)./(uzlazni_napon)-3.3;
figure(6)
plot(vrijeme_uzl,NTC_uzl);
title('Promjena NTC otpora pri zagrijavanju sistema')
grid on;
xlabel('Vrijeme [s]');
ylabel('Otpor [k\Omega]');
Temperatura_uzlazno = b./(log(NTC_uzl./a))-273;
figure(7)
plot(vrijeme_uzl,Temperatura_uzlazno);
title('Promjena temperature pri zagrijavanju sistema')
grid on;
xlabel('Vrijeme [s]');
ylabel('Temperatura [\circ C]');
%Napomena znaci moja NTC je povezana sa temperaturom preko KELVINA, ali je
%pretvaram u C na kraju zbog lakseg ocitavanja
%K = 65, a T_zag  = 215.6 s
figure(8)
NTC_sil = (8*3.3)./(silazni_napon)-3.3;
plot(vrijeme_sil,NTC_sil);
title('Promjena NTC otpora pri hla�enju sistema')
grid on;
xlabel('Vrijeme [s]');
ylabel('Otpor [k\Omega]');
Temperatura_silazno = b./(log(NTC_sil./a))-273;
figure(9)
plot(vrijeme_sil,Temperatura_silazno);
title('Promjena temperature pri hla�enju sistema')
grid on;
xlabel('Vrijeme [s]');
ylabel('Temperatura [\circ C]');
% K_z = 65;
% T_z  = 215.6;
% K_h = 51.4;
% T_h = 90.58;
% K_z = 66.37;
% T_z  = 266.7;
% K_h = 51.27;
% T_h = 110.9;
K_z = 65;
T_z  = 176.48;
K_h = 51.4;
T_h = 74.82;
figure(10)
plot(vrijeme_sim,provjera_sim);
grid on;
title('Simulacija pona�anja sistema');
xlabel('Vrijeme [s]')
ylabel('Temperatura [\circ C]')
%Hocu da lineariziram NTC karakteristiku oko radne ta�ke
R_za_lin = [3.25 3.06 2.93 2.87 2.7 3.654 3.556 3.439 3.27 3.179];
T_za_lin = [37 38 39 40 41 37 38 39 40 41];
% p1 =     -0.1263  (-0.2589, 0.006337)
% p2 =       8.117  (2.94, 13.29)
%SSE: 0.5293
%R-square: 0.3761 SUPER APROKSIMACIJA ZA OVAJ OPSEG
% figure(11)
% R_lin = -0.1263 .* T_za_lin +  8.117;
% plot(T_za_lin,R_lin);
% xlabel('Temperatura [\circ C]');
% ylabel('Otpor [k\Omega]');
%Sada je lako da izbaci kolika je temperatura
%Kada dosegne napon praga prelazi se na ovu karakteristiku i zapocinje
%regulacija. Napon praga je po usrednjenoj karakteristici 3.928 i gornji je
%4.235. Na ovom opsegu povezanost temperature i otpora je kao ovdje gore.
%Interfejs je jednostavno napraviti da izbacuje kolika je temperatura.
figure(11)
Napon_finale = Napon_1.data; 
Napon_finale = reshape(Napon_finale,[],1);
Napon_finale(end) = [];
Vrijeme_finale = t_1.data; 
Vrijeme_finale = reshape(Vrijeme_finale,[],1);
plot(Vrijeme_finale,Napon_finale);
R_finale = (3.3.*8 - Napon_finale.* 3.3)./Napon_finale;
Temperatura_finale = (3741./( (log(R_finale ./ 1.964e-05))) - 273);
plot(Vrijeme_finale,Temperatura_finale);
grid on;
xlabel('Vrijeme [s]');
ylabel('Temperatura [\circ C]');
title('Regulacija temperature uz pomo� ventilatora');
% cf_vrijeme_sil = vrijeme_sil(1:10:end);
% cf_vrijeme_uzl = vrijeme_uzl(7096:10:end);
% cf_temp_uzl = Temperatura_uzlazno(7096:10:end);
% cf_temp_sil = Temperatura_silazno(1:10:end);
